

import UIKit


enum CellType {
    
    case UserMatchRides
    case UserRides
}


class MyRideUser: UITableViewCell {

    @IBOutlet weak var chatButtonUser: UIButton!
    @IBOutlet weak var chatButton: UIButton!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var to: UILabel!
    @IBOutlet weak var from: UILabel!
    @IBOutlet weak var requestButton: UIButton!
    @IBOutlet weak var requestStack: UIStackView!
    @IBOutlet weak var noRideView: UIView!
    @IBOutlet weak var mainStackView: UIStackView!
    @IBOutlet weak var riderEmail: UILabel!
    @IBOutlet weak var riderName: UILabel!
    
    @IBOutlet weak var rejectButton: UIButton!
    @IBOutlet weak var acceptButton: UIButton!
    @IBOutlet weak var acceptRejectStack: UIStackView!
    @IBOutlet weak var riderEmailStack: UIStackView!
    @IBOutlet weak var riderNameStack: UIStackView!
    func setSell(ride:RidesModelStruct, cellType:CellType){
    
        if(ride.status == RIDE_STATUS.OPEN.rawValue) {
            self.status.textColor = .black
        }
        
        if(ride.status == RIDE_STATUS.ACCEPTED.rawValue) {
            self.status.textColor = .green
        }
        
        if(ride.status == RIDE_STATUS.REJECTED.rawValue) {
            self.status.textColor = .red
        }
        
        if(ride.status == RIDE_STATUS.REQUESTED.rawValue) {
            self.status.textColor = .orange
        }
        
        if(ride.status == RIDE_STATUS.REQUESTED.rawValue) {
            self.status.textColor = .orange
        }
        
        
        if(UserDefaultsManager.shared.getUserType() == .USER && cellType == .UserMatchRides) {
            self.requestStack.isHidden = false
            
            if(ride.status == RIDE_STATUS.REJECTED.rawValue) {
                self.requestStack.isHidden = true
            }
            
            if(ride.status == RIDE_STATUS.REQUESTED.rawValue) {
                self.requestButton.isHidden = true
            }else {
                self.requestButton.isHidden = false
            }
            
        }else {
            self.requestStack.isHidden = true
        }
        
        
        if(UserDefaultsManager.shared.getUserType() == .RIDER) {
            
            if(ride.status == RIDE_STATUS.REQUESTED.rawValue) {
                self.status.text = "Request Received"
            }else {
                self.status.text =  ride.status.capitalized
            }
           
        }else {
            self.status.text =  ride.status.capitalized
          
        }
        
        if(UserDefaultsManager.shared.getUserType() == .RIDER &&  cellType == .UserMatchRides) {
            
            if(ride.status == RIDE_STATUS.REQUESTED.rawValue ) {
                self.acceptRejectStack.isHidden = false
                self.acceptButton.isHidden = false
                self.rejectButton.isHidden = false
            }
            
            if(ride.status == RIDE_STATUS.ACCEPTED.rawValue ) {
                self.acceptRejectStack.isHidden = false
                self.acceptButton.isHidden = true
                self.rejectButton.isHidden = true
            }
            
            if(ride.status == RIDE_STATUS.REJECTED.rawValue ) {
                self.acceptRejectStack.isHidden = true
            }
            
          
        }else {
              self.acceptRejectStack.isHidden = true
        }
        
       
      
        self.from.text = ride.from
        self.to.text = ride.to
        self.date.text = ride.date
        
        
        
        if(cellType == .UserMatchRides) {
            self.riderNameStack.isHidden = false
            self.riderEmailStack.isHidden = false
            self.riderName.text = CoreDataManager.shared.getName(email:ride.email)
            self.riderEmail.text = ride.email
        }else {
            self.riderNameStack.isHidden = true
            self.riderEmailStack.isHidden = true
        }
        
        if(cellType == .UserMatchRides) {
            
                if(ride.status == RIDE_STATUS.REQUESTED.rawValue) {
                    self.requestButton.setTitle("Requested", for: .normal)
                    self.requestButton.setTitleColor(.orange, for: .normal)
                }else{
                    self.requestButton.setTitle("Request", for: .normal)
                    self.requestButton.setTitleColor(.blue, for: .normal)
                }
            
        }
        
        
        
        if(cellType == .UserMatchRides && UserDefaultsManager.shared.getUserType() == .USER && ride.status != RIDE_STATUS.OPEN.rawValue) {
            
            chatButtonUser.isHidden = false
            
        }else {
            chatButtonUser.isHidden = true
        }
        
        if(UserDefaultsManager.shared.getUserType() == .USER &&  cellType == .UserMatchRides) {
            
            if(ride.status == RIDE_STATUS.REQUESTED.rawValue || ride.status == RIDE_STATUS.ACCEPTED.rawValue ) {
                self.requestStack.isHidden = false
                self.requestButton.isHidden = true
                self.chatButtonUser.isHidden = false
            }
            
            
            
            if(ride.status == RIDE_STATUS.REJECTED.rawValue ) {
                self.requestStack.isHidden = true
            }
            
          
        } 
        
        
        
    }
}


