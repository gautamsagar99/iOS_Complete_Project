import Foundation
import UIKit
 
class AlertMessages {
    
   static let  WrongPassword = "Please enter correct password"
   static let  EmailAlreadyExist =  "This Email is Already Registerd!!"
    
}
struct AppColors {
    static let primary = UIColor(hexString: "447BF8")
}
