import Foundation
import CoreData

class CoreDataManager {
    static let shared = CoreDataManager()
    
    private lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "StudentCommute")
        container.loadPersistentStores { (_, error) in
            if let error = error {
                fatalError("Failed to load persistent stores: \(error)")
            }
        }
        return container
    }()
    
    func getChats(ride:RidesModelStruct) -> [MessageModel] {
        
        let chatId = getChatID(email1: ride.email, email2: UserDefaultsManager.shared.getEmail())
        
        print(chatId)
        
//        var matchingRides: [RidesModelStruct] = []
        
        let managedContext = persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<Chat>(entityName: "Chat")
        fetchRequest.predicate = NSPredicate(format: "chatId == %@", chatId)
        
        do {
            let chats = try managedContext.fetch(fetchRequest)
    
            if(chats.count == 0 ){
                return []
            }
            
            
            
            let chatsModel = chats.map {  chat -> MessageModel in
                
                let data = MessageModel(from: chat.from!, to: chat.to!, text: chat.text!, dateSent: chat.dateSent, chatId: chat.chatId!)
               
                return data
            }
            
            return chatsModel
            
        } catch let error as NSError {
            print("Could not fetch rides. \(error), \(error.userInfo)")
            return []
        }
       
       
    }
    
    func saveChat(ride:RidesModelStruct,text:String,time:Double){
        
        let to = ride.email
        let from = UserDefaultsManager.shared.getEmail()
        
        print(to)
        print(from)
        
        let chatID = getChatID(email1: to, email2: from)
        
        let managedContext = persistentContainer.viewContext
        
        let message = Chat(context: managedContext)
        message.from = from
        message.to = to
        message.text = text
        message.dateSent = time
        message.chatId = chatID
        
        try! managedContext.save()
    }
   
     
    func requestRide(ride:RidesModelStruct){
        
        
        let id = ride.id

        let managedContext = persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<Ride>(entityName: "Ride")
       
        fetchRequest.predicate = NSPredicate(format: "id == %@", id)
     
       
                let result = try! managedContext.fetch(fetchRequest)
        
                    let rideToUpdate = result.first!
                    rideToUpdate.requestFromName = CoreDataManager.shared.getName(email: UserDefaultsManager.shared.getEmail())
                    rideToUpdate.requestFromEmail =  UserDefaultsManager.shared.getEmail()
                    rideToUpdate.status = RIDE_STATUS.REQUESTED.rawValue
                    try! managedContext.save()
       
    }
    
    
    func acceptRide(ride:RidesModelStruct){
        
        let id = ride.id

        let managedContext = persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<Ride>(entityName: "Ride")
       
        fetchRequest.predicate = NSPredicate(format: "id == %@", id)
     
                let result = try! managedContext.fetch(fetchRequest)
        
                    let rideToUpdate = result.first!
                    rideToUpdate.status = RIDE_STATUS.ACCEPTED.rawValue
                    try! managedContext.save()
       
    }
    
    
    func rejectRide(ride:RidesModelStruct){
        
        let id = ride.id

        let managedContext = persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<Ride>(entityName: "Ride")
       
        fetchRequest.predicate = NSPredicate(format: "id == %@", id)
     
                let result = try! managedContext.fetch(fetchRequest)
        
                    let rideToUpdate = result.first!
                    rideToUpdate.status = RIDE_STATUS.REJECTED.rawValue
                    try! managedContext.save()
       
    }
    
    
    
    func changeMyRideStaus(rideStatus:String,ride:RidesModelStruct,requestToName:String,requestToEmail:String){
        
        let from = ride.from
        let to = ride.to
        let date = ride.date
       
        let managedContext = persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<Ride>(entityName: "Ride")
       
        fetchRequest.predicate = NSPredicate(format: "from == %@ AND to == %@ AND date == %@ AND email == %@", from, to, date, UserDefaultsManager.shared.getEmail().lowercased())
      
       
                let result = try! managedContext.fetch(fetchRequest)
        
                    let rideToUpdate = result.first!
                    rideToUpdate.requestToName = requestToName
                    rideToUpdate.requestToEmail = requestToEmail
                    rideToUpdate.status = rideStatus
                    try! managedContext.save()
        
       
    }
    
    
    func changeMyRideStausAcceptReject(rideStatus:String,ride:RidesModelStruct){
        
        let from = ride.from
        let to = ride.to
        let date = ride.date
       
        let managedContext = persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<Ride>(entityName: "Ride")
       
        fetchRequest.predicate = NSPredicate(format: "from == %@ AND to == %@ AND date == %@ AND email == %@", from, to, date, UserDefaultsManager.shared.getEmail().lowercased())
      
                let result = try! managedContext.fetch(fetchRequest)
        
                    let rideToUpdate = result.first!
                    rideToUpdate.status = rideStatus
                    try! managedContext.save()
        
       
    }
    
    
    func saveRide(from:String,to:String,date:String){
        
        let email = UserDefaultsManager.shared.getEmail().lowercased()
        let managedContext = persistentContainer.viewContext
         
 
        // Check if a ride with the same from, to, date, and email already exists
          let fetchRequest = NSFetchRequest<Ride>(entityName: "Ride")
          fetchRequest.predicate = NSPredicate(format: "from == %@ AND to == %@ AND date == %@ AND email == %@", from, to, date, email)
          
              let results = try! managedContext.fetch(fetchRequest)
              
              if(results.count > 0) {
                  showAlertAnyWhere(message: "Ride already exists.")
                  return
              }
            
          
        
        let ride = Ride(context: managedContext)
        ride.from = from
        ride.to = to
        ride.requestFromName = ""
        ride.requestFromEmail = ""
        ride.requestToEmail = ""
        ride.requestToName = ""
        ride.status = RIDE_STATUS.OPEN.rawValue
        ride.date =  date
        ride.email = email
        ride.id = (NSDate().timeIntervalSince1970).description
        
        
        do {
            print("Ride Saved")
            try managedContext.save()
            showAlertAnyWhere(message: "Ride Saved")
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
        
    }
    
    
    func getName(email:String) ->String{
        
        let managedContext = persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<User>(entityName: "User")
        fetchRequest.predicate = NSPredicate(format: "email == %@", email)
     
        
        let users = try! managedContext.fetch(fetchRequest)
        return users.first!.name!
        
    }
    func getMatchingRides() -> [RidesModelStruct] {
        
        let myEmail = UserDefaultsManager.shared.getEmail().lowercased()
        
        var matchingRides: [RidesModelStruct] = []
        
        let myAllRides = self.getOnlyMyRide()
        
        let allUserRides = self.getAllUserRides()
       
        
        for myRide in myAllRides {
            
                let from = myRide.from
                let to = myRide.to
                let date = myRide.date
                    
                for userRide in allUserRides {
                    if userRide.from == from && userRide.to == to && userRide.date == date && userRide.email != myEmail {
                        matchingRides.append(userRide)
                    }
                }
            }
        return matchingRides
    }
    
    
    func getAllUserRides() -> [RidesModelStruct] {
        let managedContext = persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<Ride>(entityName: "Ride")
       
           let sortDescriptor = NSSortDescriptor(key: "id", ascending: false)
           fetchRequest.sortDescriptors = [sortDescriptor]
          
        
       
        do {
            let rides = try managedContext.fetch(fetchRequest)
    
            if(rides.count == 0 ){
                return []
            }
            
            
            
            let ridesModel = rides.map {  ride -> RidesModelStruct in
                
                print( ride.status!)
                
                
                let data = RidesModelStruct(status: ride.status!, date: ride.date!, email: ride.email!, from: ride.from!, to: ride.to!, requestFromEmail: ride.requestFromEmail!, requestFromName: ride.requestFromName!, id: ride.id!,requestToEmail: ride.requestToEmail ?? "" , requestToName: ride.requestToName ?? "")
                
               
                return data
            }
            
            return ridesModel
            
        } catch let error as NSError {
            print("Could not fetch rides. \(error), \(error.userInfo)")
            return []
        }
    }
    
    
    func getOnlyMyRide() -> [RidesModelStruct] {
        let email = UserDefaultsManager.shared.getEmail().lowercased()
        let managedContext = persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<Ride>(entityName: "Ride")
        let sortDescriptor = NSSortDescriptor(key: "id", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
      
        
        fetchRequest.predicate = NSPredicate(format: "email == %@", email)
        
        do {
            let rides = try managedContext.fetch(fetchRequest)
    
            if(rides.count == 0 ){
                return []
            }
            
            
            
            let ridesModel = rides.map {  ride -> RidesModelStruct in
                
                print( ride.status!)
                
                
                let data = RidesModelStruct(status: ride.status!, date: ride.date!, email: ride.email!, from: ride.from!, to: ride.to!, requestFromEmail: ride.requestFromEmail!, requestFromName: ride.requestFromName!, id: ride.id!,requestToEmail: ride.requestToEmail ?? "",requestToName: ride.requestToName ?? "")
                
               
                return data
            }
            
            return ridesModel
            
        } catch let error as NSError {
            print("Could not fetch rides. \(error), \(error.userInfo)")
            return []
        }
    }

    
    func isAlreadyRegister(_ email: String) -> Bool {
            let fetchRequest = NSFetchRequest<User>(entityName: "User")
            fetchRequest.predicate = NSPredicate(format: "email == %@", email)
            
            do {
                let count = try persistentContainer.viewContext.count(for: fetchRequest)
                return count > 0
            } catch {
                print("Error checking if email is already saved. Error: \(error)")
                return false
            }
        }
    
    func signUp(name: String, email: String, phone:String,password: String, userType: String){
        
        let email = email.lowercased()
        
        if(isAlreadyRegister(email)) {
            showAlertAnyWhere(message: "Email Already Registered")
            return
        }
        
        let managedContext = persistentContainer.viewContext
        
        let user = User(context: managedContext)
        user.name = name
        user.email = email
        user.password = password
        user.userType = userType
        user.phone = phone
        
        do {
            try managedContext.save()
            showOkAlertAnyWhereWithCallBack(message: "Registered") {
                SceneDelegate.shared?.checkLogin()
            }
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    func login(email: String, password: String) {
        
            let email = email.lowercased()
        
            let managedContext = persistentContainer.viewContext
            
            let fetchRequest = NSFetchRequest<User>(entityName: "User")
            fetchRequest.predicate = NSPredicate(format: "email == %@", email)
            
            do {
                let users = try managedContext.fetch(fetchRequest)
                guard let user = users.first else {
                    showAlertAnyWhere(message: "Email not found")
                    return
                }
                if user.password == password {
                    UserDefaultsManager.shared.saveData(email: user.email!, userType: user.userType!)
                    SceneDelegate.shared?.checkLogin()
                } else {
                    showAlertAnyWhere(message: "Password does not match")
                    return
                }
            } catch let error as NSError {
                print("Could not fetch. \(error), \(error.userInfo)")
                return
            }
        }
        
    
    func updateUser(_ user: User)  {
        let managedContext = persistentContainer.viewContext
        
        do {
            try managedContext.save()
            showAlertAnyWhere(message: "Updated")
        } catch let error as NSError {
           print(error)
        }
    }
    
    func getCurrentUser() -> User? {
        
        let email = UserDefaultsManager.shared.getEmail().lowercased()
        
        let managedContext = persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<User>(entityName: "User")
        fetchRequest.predicate = NSPredicate(format: "email == %@", email)
     
        
        do {
            let users = try managedContext.fetch(fetchRequest)
            return users.first
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
            return nil
        }
        
       
        
        
    }
    
    func clearDatabase() {
            for entityName in persistentContainer.managedObjectModel.entities.map({ $0.name! }) {
                let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: entityName)
                let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
                
                do {
                    try persistentContainer.viewContext.execute(batchDeleteRequest)
                    print("\(entityName) table cleared successfully.")
                } catch {
                    print("Failed to clear \(entityName) table. Error: \(error)")
                }
            }
        }
        
}

 
