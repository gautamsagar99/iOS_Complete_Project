
import UIKit

class HomeVC: UIViewController , UITextFieldDelegate {
    
    @IBOutlet weak var fromTF: UITextField!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var toTF: UITextField!
    @IBOutlet weak var dateLabel: ClickableLabel!
    var setLocationFor = ""
    override func viewDidLoad() {
        
        fromTF.delegate = self
        toTF.delegate = self
        
        // Add a tap gesture recognizer to the text field
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(fromTapped))
        fromTF.addGestureRecognizer(tapGesture)
        
        let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(toTapped))
        toTF.addGestureRecognizer(tapGesture2)
        
        dateLabel.onClick = {
            self.openDatePicker()
        }
       
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.name.text = CoreDataManager.shared.getCurrentUser()!.name
    }
    
    
    // Implement UITextFieldDelegate method to disallow editing
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return false
    }
    
    
    @objc func fromTapped() {
        self.setLocationFor = "From"
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LocationSelectorVC") as! LocationSelectorVC
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func toTapped() {
        self.setLocationFor = "To"
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LocationSelectorVC") as! LocationSelectorVC
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func resetFields() {
        self.fromTF.text = ""
        self.toTF.text = ""
        self.dateLabel.text = "Select date"
    }
    
    @IBAction func onSubmit(_ sender: Any) {
        
        
        if(self.fromTF.text!.isEmpty) {
            showAlert(message: "Please enter starting point")
            return
        }
        
        if(self.toTF.text!.isEmpty) {
            showAlert(message: "Please enter destination point")
            return
        }
        
        if(self.fromTF.text! == self.toTF.text!) {
            showAlert(message: "Starting point and destination can't be same")
            return
        }
        
        
        if(self.dateLabel.text! == "Select date") {
            showAlert(message: "Please add date")
            return
        }
        CoreDataManager.shared.saveRide(from:self.fromTF.text!, to:self.toTF.text!,date:self.dateLabel.text!)
        self.resetFields()
       
    }
}


extension HomeVC : LocationSelectorDelegate  {
    
    func locationSelector(location: String) {
        
        if(self.setLocationFor == "From") {
            self.fromTF.text = location
        }else {
            self.toTF.text = location
        }
    }
}

extension HomeVC {
    
    
    func openDatePicker() {
        
        let datePicker = UIDatePicker()
        datePicker.datePickerMode = .date
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.addTarget(self, action: #selector(datePickerValueChanged(_:)), for: .valueChanged)
        
        // Only can select date from now to next 6 months
        
        let currentDate = Date()
        let sixMonthsFromNow = Calendar.current.date(byAdding: .month, value: 6, to: currentDate)!
        
        datePicker.minimumDate = currentDate
        datePicker.maximumDate = sixMonthsFromNow
        
        
        let alertController = UIAlertController(title: "Select Date", message: "", preferredStyle: .actionSheet)
        alertController.view.addSubview(datePicker)
        
        let doneAction = UIAlertAction(title: "Done", style: .default) { _ in
            let selectedDate = datePicker.date
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            self.dateLabel.text = dateFormatter.string(from: selectedDate)
        }
        
        alertController.addAction(doneAction)
        alertController.view.heightAnchor.constraint(equalToConstant: 300).isActive = true
        
        present(alertController, animated: true, completion: nil)
    }
    
    @objc func datePickerValueChanged(_ sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let dateString = dateFormatter.string(from: sender.date)
        dateLabel.text = dateString
    }
}
