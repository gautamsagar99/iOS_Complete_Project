import UIKit
import Foundation

class ChatVC: UIViewController {

    @IBOutlet weak var chatContainer: UIView!
    let id =  UserDefaultsManager.shared.getEmail()
    var topTitle = ""
    var ride : RidesModelStruct!
    @IBOutlet weak var textView: TextViewWithPlaceholder!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var textViewBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var btnOptions: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var addImages: UIButton!
    @IBOutlet weak var btnViewProfile: UIButton!
    @IBOutlet weak var sendMessageView: UIView!

    var messages = [MessageModel]()
    var senderId = UserDefaultsManager.shared.getEmail()
    var senderName = CoreDataManager.shared.getName(email: UserDefaultsManager.shared.getEmail())
    
    
    func shortMessages() {
        messages = messages.sorted(by: {
            $0.getDate().compare($1.getDate()) == .orderedAscending
        })
    }
    
    func getMessages() {
        
        let messages =  CoreDataManager.shared.getChats(ride:self.ride)
        
        self.messages = messages
        self.shortMessages()
        self.reloadData()
        
      
    }

 
  

}

extension ChatVC {
 
    @IBAction func onSend(_ sender: Any) {
        
        if(self.textView.text.isEmpty) {
          
           showAlert(message: "Please enter Text")
        }
        guard let text = self.textView.text else {
            return
        }

        let msgText = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !msgText.isEmpty else {
            return
        }
 
        self.textView.text = ""
        
        self.sendTextMessage(text:msgText)

    }
    
    func getTime()-> Double {
        return Double(Date().millisecondsSince1970)
    }
    
    func sendTextMessage(text: String) {
        self.view.endEditing(true)
        CoreDataManager.shared.saveChat(ride: self.ride, text: text, time:  getTime())
        self.getMessages()
        self.tableView.reloadData()
 
    }
    
    
}


 
extension ChatVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }


    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {


        let message = messages[indexPath.row]
        if message.from ==  senderId {
            let cell = self.tableView.dequeueReusableCell(withIdentifier: "CometChatSenderTextMessageBubble") as! CometChatSenderTextMessageBubble
            cell.setData(message: message)
            return cell
            
        } else {
            let cell = self.tableView.dequeueReusableCell(withIdentifier: "CometChatReceiverTextMessageBubble") as! CometChatReceiverTextMessageBubble
            cell.setData(message: message)
            return cell
           
        }

//        return UITableViewCell()
    }

 
   
}
 


import UIKit
extension ChatVC {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.scrollIndicatorInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: tableView.bounds.size.width - 10)
        self.chatContainer.dropShadow()
       
        self.setTableView()
        self.setNameAndTitle()
        self.getMessages()
    }

    
    func setNameAndTitle() {
        self.navigationController?.title = "Chat"
    }
    
    func setTableView() {
        self.registerCells()

        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.delegate = self
        self.tableView.dataSource = self
        tableView.tableFooterView = UIView()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
    }
    
    
    
   
    
    func registerCells() {
        self.tableView.register(UINib(nibName: "CometChatSenderTextMessageBubble", bundle: nil), forCellReuseIdentifier: "CometChatSenderTextMessageBubble")
        self.tableView.register(UINib(nibName: "CometChatReceiverTextMessageBubble", bundle: nil), forCellReuseIdentifier: "CometChatReceiverTextMessageBubble")
       
    }
    
    func reloadData(){
        self.tableView.reloadData()
        self.tableView.scroll(to: .bottom, animated: true)
        self.updateTableContentInset()
    }
     
    
    //Add this function below
    func updateTableContentInset() {
        let numRows = self.tableView.numberOfRows(inSection: 0)
        var contentInsetTop = self.tableView.bounds.size.height
        for i in 0..<numRows {
            let rowRect = self.tableView.rectForRow(at: IndexPath(item: i, section: 0))
            contentInsetTop -= rowRect.size.height
            if contentInsetTop <= 0 {
                contentInsetTop = 0
                break
            }
        }
//        self.tableView.contentInset = UIEdgeInsets(top: contentInsetTop,left: 0,bottom: 0,right: 0)
    }
}


func getChatID(email1: String, email2: String) -> String {
    let comparisonResult = email1.compare(email2)
    if comparisonResult == .orderedAscending {
        return email1 + email2
    } else {
        return email2 + email1
    }
}
