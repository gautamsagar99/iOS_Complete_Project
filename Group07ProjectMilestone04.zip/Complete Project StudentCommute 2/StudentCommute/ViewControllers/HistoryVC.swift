
import UIKit

class HistoryVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var matchingRides: [RidesModelStruct] = []
    var allRides: [RidesModelStruct] = []
    var rideMatches = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.registerCells([MyRideUser.self])
    }
    
    func fetchData(){
        self.allRides = CoreDataManager.shared.getOnlyMyRide()
        self.matchingRides = CoreDataManager.shared.getMatchingRides()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        self.fetchData()
        if(self.allRides.count == 0 ) {
            showAlert(message: "There is no any rides")
            self.tableView.isHidden = true
        }else  {
            self.tableView.isHidden = false
        }
        
        if(matchingRides.count == 0) {
            self.rideMatches = false
        }else {
            self.rideMatches = true
        }
        
        self.tableView.reloadData()
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2 
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            
            if(self.rideMatches){
                return matchingRides.count
            }else {
                return 1
            }
         
        case 1:
            return allRides.count
        default:
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = UITableViewCell()
        
        let myRideCell = tableView.dequeueReusableCell(withIdentifier: MyRideUser.identifier, for: indexPath) as! MyRideUser
       
        switch indexPath.section {
            
        case 0:
            
            if(self.rideMatches){
                myRideCell.setSell(ride:self.matchingRides[indexPath.row], cellType: .UserMatchRides)
                cell = myRideCell
                myRideCell.mainStackView.isHidden = false
                myRideCell.requestButton.tag = indexPath.row
                myRideCell.chatButton.tag = indexPath.row
                myRideCell.acceptButton.tag = indexPath.row
                myRideCell.rejectButton.tag = indexPath.row
                myRideCell.requestButton.addTarget(self, action: #selector(requestButtonTap(_:)), for: .touchUpInside)
                myRideCell.chatButtonUser.addTarget(self, action: #selector(chatUserButtonTap(_:)), for: .touchUpInside)
                myRideCell.chatButton.addTarget(self, action: #selector(chatButtonTap(_:)), for: .touchUpInside)
                
                
                myRideCell.acceptButton.addTarget(self, action: #selector(onAccept(_:)), for: .touchUpInside)
                myRideCell.rejectButton.addTarget(self, action: #selector(onReject(_:)), for: .touchUpInside)
                
                
                
            }else {
                myRideCell.mainStackView.isHidden = true
            }
            
           
            cell = myRideCell

        case 1:
            myRideCell.setSell(ride:self.allRides[indexPath.row], cellType: .UserRides)
            myRideCell.mainStackView.isHidden = false
            myRideCell.requestStack.isHidden = true
            cell = myRideCell
        default:
            return cell
        }
        
        return cell
    }
    
    
    @objc func requestButtonTap(_ sender: UIButton!) {
       
        let ride = self.matchingRides[sender.tag]
        
        CoreDataManager.shared.requestRide(ride:ride)
        
        CoreDataManager.shared.changeMyRideStaus(rideStatus:  RIDE_STATUS.REQUESTED.rawValue, ride:ride,requestToName: CoreDataManager.shared.getName(email:ride.email),requestToEmail: ride.email)
        
        showOkAlertWithCallBack(message: "Requested") {
            self.fetchData()
            self.tableView.reloadData()
        }
        
    }
    
    
    @objc func onAccept(_ sender: UIButton!) {
      
        let ride = self.matchingRides[sender.tag]
        
        CoreDataManager.shared.acceptRide(ride:ride)
        
        CoreDataManager.shared.changeMyRideStausAcceptReject(rideStatus:  RIDE_STATUS.ACCEPTED.rawValue, ride:ride)
        
        showOkAlertWithCallBack(message: "Requested") {
            self.fetchData()
            self.tableView.reloadData()
        }
       
   }
    @objc func onReject(_ sender: UIButton!) {
      
        let ride = self.matchingRides[sender.tag]
        
        CoreDataManager.shared.rejectRide(ride:ride)
        
        CoreDataManager.shared.changeMyRideStausAcceptReject(rideStatus:  RIDE_STATUS.REJECTED.rawValue, ride:ride)
        
        showOkAlertWithCallBack(message: "Requested") {
            self.fetchData()
            self.tableView.reloadData()
        }
        
     
   }
    
    
     @objc func chatButtonTap(_ sender: UIButton!) {
       
         let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChatVC") as! ChatVC
         vc.ride = self.matchingRides[sender.tag]
         self.navigationController?.pushViewController(vc, animated: true)
    }
   
     
     @objc func chatUserButtonTap(_ sender: UIButton!) {
       
         let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChatVC") as! ChatVC
         vc.ride = self.matchingRides[sender.tag]
         self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch section {
        case 0:
            return "Matching Rides"
        case 1:
            return "My All Rides"
        default:
            return nil
        }
    }
    
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        guard let header = view as? UITableViewHeaderFooterView else { return }
        
        // Set background color
        header.backgroundView?.backgroundColor = UIColor.blue
        
        // Set title color and font
        header.textLabel?.textColor = UIColor.black
        header.textLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        
        // Set text alignment to left
        header.textLabel?.textAlignment = .center
    }
    
}
