
import CoreData

class UserModel: NSManagedObject {
    @NSManaged var name: String
    @NSManaged var email: String
    @NSManaged var phone: String
    @NSManaged var password: String
    @NSManaged var userType: String
}

enum UserType:String {
    case USER = "USER"
    case RIDER = "RIDER"
}



 
struct RidesModelStruct {
    var status: String
    var date: String
    var email: String
    var from: String
    var to: String
    var requestFromEmail: String
    var requestFromName: String
    var id: String
    var requestToEmail: String
    var requestToName: String
}



enum RIDE_STATUS:String {
    case ACCEPTED = "ACCEPTED"
    case REJECTED = "REJECTED"
    case OPEN = "OPEN"
    case REQUESTED = "REQUESTED"
}


 

struct MessageModel  {
    var from:String
    var to:String
    var text: String
    var dateSent: Double
    var chatId:String
  
   func getDate()->Date{
       Date(timeIntervalSince1970: dateSent)
   }
   func getDataString()->String {
       let date = Date(timeIntervalSince1970: dateSent)
       var lastMessageDatetring: String {
           let formatter = DateFormatter()
           formatter.dateFormat = "MMM d, yyyy"
           return formatter.string(from: date)
       }
       return lastMessageDatetring
   }
}
